Changelog
=========

Unreleased
----------

0.0.1
-----

- Added TOC to CKEditor created by Shaun Sephton & Piotr Malinski. Thanks to `<django-ckeditor>`_ for CKEditor.

.. _django-ckeditor: https://github.com/django-ckeditor/django-ckeditor
