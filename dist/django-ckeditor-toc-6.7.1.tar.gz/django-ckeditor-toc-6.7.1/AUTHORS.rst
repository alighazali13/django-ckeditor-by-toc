AUTHORS
=======


Created By
----------
#. `shaunsephton <http://github.com/shaunsephton>`__


Contributors
------------
#. `riklaunim <https://github.com/riklaunim>`__
#. `3point2 <https://github.com/3point2>`__
#. `buchuki <http://github.com/buchuki>`__
#. `chr15m <http://github.com/chr15m>`__
#. `hedleyroos <https://github.com/hedleyroos>`__
#. `jeffh <https://github.com/jeffh>`__
#. `lihan <https://github.com/lihan>`__
#. `loop0 <http://github.com/loop0>`__
#. `mwcz <https://github.com/mwcz>`__
#. `tomwys <https://github.com/tomwys>`__
#. `snbuback <https://github.com/snbuback>`__
#. And others `<https://github.com/django-ckeditor/django-ckeditor/graphs/contributors>`__
